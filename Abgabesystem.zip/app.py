from flask import Flask, render_template, request, redirect, url_for, session, flash
import os
import random
import string
import json
import datetime
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'

# Konfiguration
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB
app.config['ALLOWED_EXTENSIONS'] = {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'mp4'}

# Tokens für Git-Repo Challenge
TOKENS = {
    "group1": "7FgT2k9mR",
    "group2": "Xp5L8yQ3z",
    "group3": "Bn6V4dS1w",
    "group4": "K8jR3mN7q",
    "group5": "T9hY4vP2c",
    "group6": "L6kM9bW5e"
}
# Speichere Tokens in einer Datei
with open('tokens.json', 'w') as f:
    json.dump(TOKENS, f)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/select_group', methods=['POST'])
def select_group():
    group = request.form.get('group')
    session['group'] = group
    return redirect(url_for('group_dashboard'))

@app.route('/dashboard')
def group_dashboard():
    if 'group' not in session:
        return redirect(url_for('index'))
    return render_template('group_selection.html', group=session['group'])

# Füge diese Route hinzu
@app.route('/git_clone', methods=['GET', 'POST'])
def git_clone():
    if 'group' not in session:
        return redirect(url_for('index'))
    
    group = session['group']
    message = None
    
    # Überprüfen ob die Gruppe bereits erfolgreich war
    completed_path = os.path.join(app.config['UPLOAD_FOLDER'], 'tokens', f"{group}_completed.txt")
    if os.path.exists(completed_path):
        return render_template('success.html', 
                           title="Git-Repo klonen",
                           message="Du habst diese Audgabe bereits erfolgreich abgeschlossen!")
    
    if request.method == 'POST':
        token = request.form.get('token')
        
        if token == TOKENS.get(group):
            # Erfolg!
            os.makedirs(os.path.dirname(completed_path), exist_ok=True)
            with open(completed_path, 'w') as f:
                f.write("completed")
            
            return render_template('success.html', 
                               title="Git-Repo klonen",
                               message="Herzlichen Glückwunsch! Du hast das Repo erfolgreich geklont.")
        else:
            message = "Ungültiger Token. Bitte versuche es erneut."
    
    return render_template('git_clone.html', 
                         group=group,
                         message=message)

import subprocess

@app.route('/metadata', methods=['GET', 'POST'])
def metadata():
    if 'group' not in session:
        return redirect(url_for('index'))
    
    group = session['group']
    message = None
    
    completed_path = os.path.join(app.config['UPLOAD_FOLDER'], 'metadata', f"{group}_completed.txt")
    if os.path.exists(completed_path):
        return render_template('success.html', 
                           title="Metadatenanalyse",
                           message="Du hast diese Aufgabe bereits abgeschlossen!")

    if request.method == 'POST':
        lat = request.form.get('latitude')
        lon = request.form.get('longitude')
        address = request.form.get('address')
        
        if 'image' not in request.files:
            message = "Bitte lade ein Bild hoch."
        else:
            file = request.files['image']
            if file.filename == '':
                message = "Keine Datei ausgewählt."
            elif file and allowed_file(file.filename):
                filename = secure_filename(f"{group}_{file.filename}")
                upload_path = os.path.join(app.config['UPLOAD_FOLDER'], 'metadata', filename)
                os.makedirs(os.path.dirname(upload_path), exist_ok=True)
                file.save(upload_path)
                
                try:
                    result = subprocess.run(['exiftool', upload_path], capture_output=True, text=True)
                    if "GPS Latitude" in result.stdout or "GPS Longitude" in result.stdout:
                        # Lösche das Bild sofort
                        os.remove(upload_path)
                        message = "Das Bild enthält noch Metadaten! Es wurde gelöscht. Bitte lade ein bereinigtes Bild hoch."
                    else:
                        # Speichere Metadaten in JSON
                        metadata_data = {
                            "group": group,
                            "latitude": lat,
                            "longitude": lon,
                            "address": address,
                            "image_filename": filename
                        }
                        json_path = os.path.join(app.config['UPLOAD_FOLDER'], 'metadata', f"{group}_result.json")
                        with open(json_path, 'w') as f:
                            json.dump(metadata_data, f)
                        
                        # Markiere als abgeschlossen
                        with open(completed_path, 'w') as f:
                            f.write("completed")
                        
                        return render_template('success.html', 
                                           title="Metadatenanalyse",
                                           message="Herzlichen Glückwunsch! du habst alle Metadaten erfolgreich entfernt.")
                except Exception as e:
                    # Lösche das Bild bei Fehlern
                    if os.path.exists(upload_path):
                        os.remove(upload_path)
                    message = f"Fehler bei der Überprüfung: {str(e)}. Das Bild wurde gelöscht."
            else:
                message = "Ungültiger Dateityp. Nur Bilder sind erlaubt."
    
    return render_template('metadata.html', 
                         group=group,
                         message=message)

def allowed_file(filename):
    """Prüft ob die Dateiendung erlaubt ist"""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

# Füge diese Route hinzu
@app.route('/passwords', methods=['GET', 'POST'])
def passwords():
    if 'group' not in session:
        return redirect(url_for('index'))
    
    group = session['group']
    message = None
    
    # Überprüfen ob die Gruppe bereits erfolgreich war
    completed_path = os.path.join(app.config['UPLOAD_FOLDER'], 'passwords', f"{group}_completed.txt")
    if os.path.exists(completed_path):
        return render_template('success.html', 
                           title="Passwortsicherheit",
                           message="Du hast diese Aufgabe bereits abgeschlossen!")
    
    if request.method == 'POST':
        attack_type = request.form.get('attack_type')
        password = request.form.get('password')
        
        # PDF hochladen
        if 'pdf' not in request.files:
            message = "Bitte lade eine PDF-Datei hoch."
        else:
            file = request.files['pdf']
            if file.filename == '':
                message = "Keine Datei ausgewählt."
            elif file and allowed_file(file.filename) and file.filename.lower().endswith('.pdf'):
                filename = secure_filename(f"{group}_{attack_type}_{file.filename}")
                upload_path = os.path.join(app.config['UPLOAD_FOLDER'], 'passwords', filename)
                os.makedirs(os.path.dirname(upload_path), exist_ok=True)
                file.save(upload_path)
                
                # Überprüfen ob alle Angriffe durchgeführt wurden
                files = os.listdir(os.path.join(app.config['UPLOAD_FOLDER'], 'passwords'))
                group_files = [f for f in files if f.startswith(group)]
                
                has_dict_attack = any('dictionary' in f.lower() for f in group_files)
                has_brute_attack = any('brute' in f.lower() for f in group_files)
                
                if has_dict_attack and has_brute_attack:
                    # Erfolg!
                    with open(completed_path, 'w') as f:
                        f.write("completed")
                    return render_template('success.html', 
                                       title="Passwortsicherheit",
                                       message="Herzlichen Glückwunsch! Du hast beide Angriffe erfolgreich durchgeführt.")
                else:
                    message = "Du musst noch beide Angriffstypen durchführen (Wörterbuchangriff und Brute-Force)."
            else:
                message = "Ungültiger Dateityp. Nur PDF-Dateien sind erlaubt."
    
    return render_template('passwords.html', 
                         group=group,
                         message=message)


# Füge diese Route hinzu
@app.route('/veracrypt', methods=['GET', 'POST'])
def veracrypt():
    if 'group' not in session:
        return redirect(url_for('index'))
    
    group = session['group']
    message = None
    
    # Überprüfen ob die Gruppe bereits erfolgreich war
    completed_path = os.path.join(app.config['UPLOAD_FOLDER'], 'veracrypt', f"{group}_completed.txt")
    if os.path.exists(completed_path):
        return render_template('success.html', 
                           title="Veracrypt",
                           message="Du hast diese Aufgabe bereits abgeschlossen!")
    
    if request.method == 'POST':
        if 'video' not in request.files:
            message = "Bitte lade ein Video (mp4) hoch."
        else:
            file = request.files['video']
            if file.filename == '':
                message = "Keine Datei ausgewählt."
            elif file and allowed_file(file.filename) and file.filename.lower().endswith('.mp4'):
                filename = secure_filename(f"{group}_{file.filename}")
                upload_path = os.path.join(app.config['UPLOAD_FOLDER'], 'veracrypt', filename)
                os.makedirs(os.path.dirname(upload_path), exist_ok=True)
                file.save(upload_path)
                
                # Erfolg!
                with open(completed_path, 'w') as f:
                    f.write("completed")
                
                return render_template('success.html', 
                                   title="Veracrypt",
                                   message="Herzlichen Glückwunsch! Du hast den versteckten Container hochgeladen.")
            else:
                message = "Ungültiger Dateityp. Nur MP4-Videos sind erlaubt."
    
    return render_template('veracrypt.html', 
                         group=group,
                         message=message)

@app.route('/fakenews', methods=['GET', 'POST'])
def fakenews():
    if 'group' not in session:
        return redirect(url_for('index'))
    
    group = session['group']
    message = None
    
    completed_path = os.path.join(app.config['UPLOAD_FOLDER'], 'fakenews', f"{group}_completed.txt")
    if os.path.exists(completed_path):
        return render_template('success.html', 
                           title="Fake-News-Analyse",
                           message="Challenge bereits abgeschlossen!")

    if request.method == 'POST':
        # Daten sammeln
        entries = [
            {
                "url": request.form.get('url1'),
                "year": request.form.get('year1')
            },
            {
                "url": request.form.get('url2'),
                "year": request.form.get('year2')
            },
            {
                "url": request.form.get('url3'), 
                "year": request.form.get('year3')
            }
        ]

        # Validierung
        if not all(entry['url'] and entry['year'] for entry in entries):
            message = "Bitte alle Felder ausfüllen!"
        else:
            # Ordner erstellen falls nicht existent
            os.makedirs(os.path.join(app.config['UPLOAD_FOLDER'], 'fakenews'), exist_ok=True)
            
            # Daten speichern
            data = {
                "group": group,
                "entries": entries
            }
            
            with open(os.path.join(app.config['UPLOAD_FOLDER'], 'fakenews', f"{group}_result.json"), 'w') as f:
                json.dump(data, f)
            
            # Als abgeschlossen markieren
            with open(completed_path, 'w') as f:
                f.write("completed")
            
            return render_template('success.html',
                               title="Fake-News-Analyse",
                               message="Daten erfolgreich gespeichert!")

    return render_template('fakenews.html',
                         group=group,
                         message=message)
# Füge diese Imports hinzu
from flask import send_from_directory
import glob

# Admin-Login (einfache Variante mit festem Passwort)
ADMIN_PASSWORD = "fische"  # Ändere das!

@app.route('/admin', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        password = request.form.get('password')
        if password == ADMIN_PASSWORD:
            session['is_admin'] = True
            return redirect(url_for('admin_dashboard'))
        else:
            flash("Falsches Passwort!", "danger")
    return render_template('admin_login.html')

@app.route('/admin/dashboard')
def admin_dashboard():
    if not session.get('is_admin'):
        return redirect(url_for('admin_login'))
    
    # Sammle alle Abgaben
    submissions = {
        "git_tokens": [],
        "metadata": [],
        "passwords": [],
        "veracrypt": [],
        "fakenews": []
    }

    # 1. Git-Tokens
    for group in TOKENS.keys():
        completed_file = f"static/uploads/tokens/{group}_completed.txt"
        if os.path.exists(completed_file):
            submissions["git_tokens"].append(group)

    # 2. Metadaten
    metadata_dir = os.path.join(app.config['UPLOAD_FOLDER'], 'metadata')
    if os.path.exists(metadata_dir):
        for filename in os.listdir(metadata_dir):
            if filename.endswith('_result.json'):
                try:
                    with open(os.path.join(metadata_dir, filename), 'r') as f:
                        data = json.load(f)
                        submissions["metadata"].append({
                            "group": data["group"],
                            "latitude": data["latitude"],
                            "longitude": data["longitude"],
                            "address": data["address"],
                            "image": data["image_filename"]
                        })
                except Exception as e:
                    print(f"Fehler beim Laden von {filename}: {e}")
                    continue

    # 3. Passwörter
    password_dir = os.path.join(app.config['UPLOAD_FOLDER'], 'passwords')
    if os.path.exists(password_dir):
        for filename in os.listdir(password_dir):
            if not filename.endswith('_completed.txt'):
                submissions["passwords"].append({
                    "group": filename.split('_')[0],
                    "file": filename,
                    "type": "Wörterbuch" if "dictionary" in filename else "Brute-Force"
                })

    # 4. Veracrypt
    veracrypt_dir = os.path.join(app.config['UPLOAD_FOLDER'], 'veracrypt')
    if os.path.exists(veracrypt_dir):
        for filename in os.listdir(veracrypt_dir):
            if not filename.endswith('_completed.txt'):
                submissions["veracrypt"].append({
                    "group": filename.split('_')[0],
                    "file": filename
                })

    # 5. Fake-News
    fakenews_dir = os.path.join(app.config['UPLOAD_FOLDER'], 'fakenews')
    if os.path.exists(fakenews_dir):
        for filename in os.listdir(fakenews_dir):
            if filename.endswith('_result.json'):
                try:
                    with open(os.path.join(fakenews_dir, filename), 'r') as f:
                        data = json.load(f)
                        submissions["fakenews"].append({
                            "group": data["group"],
                            "entries": data["entries"]
                        })
                except Exception as e:
                    print(f"Fehler beim Laden von {filename}: {e}")
                    continue

    return render_template('admin_dashboard.html', submissions=submissions)  # <- WICHTIG: Dieser return war verschoben

@app.route('/admin/download/<path:filename>')
def download_file(filename):
    if not session.get('is_admin'):
        return redirect(url_for('admin_login'))
    
    # Sicherheitscheck: Nur erlaubte Pfade
    if "metadata" in filename:
        return send_from_directory(os.path.join(app.config['UPLOAD_FOLDER'], 'metadata'), filename)
    elif "passwords" in filename:
        return send_from_directory(os.path.join(app.config['UPLOAD_FOLDER'], 'passwords'), filename)
    elif "veracrypt" in filename:
        return send_from_directory(os.path.join(app.config['UPLOAD_FOLDER'], 'veracrypt'), filename)
    else:
        return "Datei nicht gefunden", 404

 

    # Sicherstellen, dass wir immer ein Template zurückgeben
    return render_template('admin_dashboard.html', submissions=submissions)
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)